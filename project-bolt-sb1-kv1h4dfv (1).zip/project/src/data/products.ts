import { Product, Category } from '../types';

export const categories: Category[] = [
  {
    id: 'jewelry',
    name: 'Premium Jewelry',
    icon: 'Gem',
    description: 'Luxury watches, necklaces, and designer accessories',
    productCount: 45,
    image: 'https://images.pexels.com/photos/1927259/pexels-photo-1927259.jpeg?auto=compress&cs=tinysrgb&w=800',
  },
  {
    id: 'clothing',
    name: 'Designer Clothing',
    icon: 'Shirt',
    description: 'Fashion-forward apparel for special occasions',
    productCount: 120,
    image: 'https://images.pexels.com/photos/996329/pexels-photo-996329.jpeg?auto=compress&cs=tinysrgb&w=800',
  },
  {
    id: 'electronics',
    name: 'Electronics',
    icon: 'Smartphone',
    description: 'Latest gadgets and tech accessories',
    productCount: 80,
    image: 'https://images.pexels.com/photos/356056/pexels-photo-356056.jpeg?auto=compress&cs=tinysrgb&w=800',
  },
  {
    id: 'footwear',
    name: 'Luxury Footwear',
    icon: 'ShirtIcon',
    description: 'Designer shoes and exclusive sneakers',
    productCount: 65,
    image: 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=800',
  },
  {
    id: 'books',
    name: 'Rare Books',
    icon: 'Book',
    description: 'Collectible and special edition publications',
    productCount: 200,
    image: 'https://images.pexels.com/photos/159711/books-bookstore-book-reading-159711.jpeg?auto=compress&cs=tinysrgb&w=800',
  },
  {
    id: 'party-supplies',
    name: 'Party & Events',
    icon: 'PartyPopper',
    description: 'Everything for memorable celebrations',
    productCount: 95,
    image: 'https://images.pexels.com/photos/1190298/pexels-photo-1190298.jpeg?auto=compress&cs=tinysrgb&w=800',
  },
];

export const products: Product[] = [
  {
    id: '1',
    name: 'Rolex Submariner',
    description: 'Iconic luxury diving watch with exceptional craftsmanship and water resistance up to 300 meters',
    price: 250,
    category: 'jewelry',
    image: 'https://images.pexels.com/photos/190819/pexels-photo-190819.jpeg?auto=compress&cs=tinysrgb&w=500',
    rating: 4.9,
    available: true,
    specifications: {
      'Brand': 'Rolex',
      'Material': 'Stainless Steel',
      'Water Resistance': '300m',
      'Movement': 'Automatic'
    },
    rentingPeriod: ['1 day', '3 days', '1 week', '2 weeks'],
  },
  {
    id: '2',
    name: 'Royal Silk Lehenga',
    description: 'Exquisite handcrafted silk lehenga with intricate gold embroidery, perfect for weddings and festivals',
    price: 180,
    category: 'clothing',
    image: 'https://images.pexels.com/photos/1021693/pexels-photo-1021693.jpeg?auto=compress&cs=tinysrgb&w=500',
    rating: 4.8,
    available: true,
    specifications: {
      'Brand': 'Sabyasachi',
      'Size': 'Multiple Available',
      'Material': 'Pure Silk',
      'Style': 'Traditional Lehenga'
    },
    rentingPeriod: ['1 day', '3 days', '1 week'],
  },
  {
    id: '3',
    name: 'MacBook Pro 16"',
    description: 'Latest MacBook Pro with M3 chip for professional work, content creation, and development',
    price: 120,
    category: 'electronics',
    image: 'https://images.pexels.com/photos/205421/pexels-photo-205421.jpeg?auto=compress&cs=tinysrgb&w=500',
    rating: 4.9,
    available: true,
    specifications: {
      'Brand': 'Apple',
      'Screen': '16-inch Retina',
      'Processor': 'M3 Pro',
      'Storage': '1TB SSD'
    },
    rentingPeriod: ['1 day', '3 days', '1 week', '2 weeks', '1 month'],
  },
  {
    id: '4',
    name: 'Louboutin Heels',
    description: 'Iconic red-soled luxury heels for special occasions and formal events',
    price: 95,
    category: 'footwear',
    image: 'https://images.pexels.com/photos/1240892/pexels-photo-1240892.jpeg?auto=compress&cs=tinysrgb&w=500',
    rating: 4.7,
    available: true,
    specifications: {
      'Brand': 'Christian Louboutin',
      'Heel Height': '4 inches',
      'Material': 'Patent Leather',
      'Sizes': '6-10 Available'
    },
    rentingPeriod: ['1 day', '3 days', '1 week'],
  },
  {
    id: '5',
    name: 'First Edition Gatsby',
    description: 'Rare first edition of The Great Gatsby by F. Scott Fitzgerald in excellent condition',
    price: 75,
    category: 'books',
    image: 'https://images.pexels.com/photos/1130980/pexels-photo-1130980.jpeg?auto=compress&cs=tinysrgb&w=500',
    rating: 4.6,
    available: true,
    specifications: {
      'Author': 'F. Scott Fitzgerald',
      'Year': '1925',
      'Condition': 'Excellent',
      'Publisher': 'Charles Scribner\'s Sons'
    },
    rentingPeriod: ['3 days', '1 week', '2 weeks'],
  },
  {
    id: '6',
    name: 'Crystal Chandelier',
    description: 'Elegant crystal chandelier for luxury events, weddings, and special celebrations',
    price: 200,
    category: 'party-supplies',
    image: 'https://images.pexels.com/photos/2034323/pexels-photo-2034323.jpeg?auto=compress&cs=tinysrgb&w=500',
    rating: 4.8,
    available: true,
    specifications: {
      'Material': 'Crystal',
      'Diameter': '36 inches',
      'Lights': '12 bulbs',
      'Style': 'Traditional'
    },
    rentingPeriod: ['1 day', '3 days', '1 week'],
  },
  {
    id: '7',
    name: 'Cartier Diamond Necklace',
    description: 'Exquisite diamond necklace from Cartier\'s prestigious collection with 18K white gold',
    price: 450,
    category: 'jewelry',
    image: 'https://images.pexels.com/photos/1454171/pexels-photo-1454171.jpeg?auto=compress&cs=tinysrgb&w=500',
    rating: 4.9,
    available: true,
    specifications: {
      'Brand': 'Cartier',
      'Material': '18K White Gold',
      'Stones': 'Natural Diamonds',
      'Carat': '5.2 total'
    },
    rentingPeriod: ['1 day', '3 days', '1 week'],
  },
  {
    id: '8',
    name: 'Designer Bridal Lehenga',
    description: 'Stunning red and gold bridal lehenga with heavy embellishments and mirror work',
    price: 320,
    category: 'clothing',
    image: 'https://images.pexels.com/photos/2897883/pexels-photo-2897883.jpeg?auto=compress&cs=tinysrgb&w=500',
    rating: 4.8,
    available: true,
    specifications: {
      'Brand': 'Manish Malhotra',
      'Material': 'Velvet & Silk',
      'Style': 'Bridal Lehenga',
      'Sizes': 'XS-XL Available'
    },
    rentingPeriod: ['1 day', '3 days', '1 week'],
  },
  {
    id: '9',
    name: 'iPhone 15 Pro Max',
    description: 'Latest iPhone 15 Pro Max with titanium design and advanced camera system',
    price: 85,
    category: 'electronics',
    image: 'https://images.pexels.com/photos/699122/pexels-photo-699122.jpeg?auto=compress&cs=tinysrgb&w=500',
    rating: 4.8,
    available: true,
    specifications: {
      'Brand': 'Apple',
      'Storage': '256GB',
      'Color': 'Natural Titanium',
      'Camera': '48MP Pro System'
    },
    rentingPeriod: ['1 day', '3 days', '1 week', '2 weeks'],
  },
  {
    id: '10',
    name: 'Gucci Sneakers',
    description: 'Limited edition Gucci sneakers with premium leather and signature design',
    price: 125,
    category: 'footwear',
    image: 'https://images.pexels.com/photos/2529148/pexels-photo-2529148.jpeg?auto=compress&cs=tinysrgb&w=500',
    rating: 4.7,
    available: true,
    specifications: {
      'Brand': 'Gucci',
      'Material': 'Premium Leather',
      'Style': 'Limited Edition',
      'Sizes': '7-12 Available'
    },
    rentingPeriod: ['1 day', '3 days', '1 week'],
  },
  {
    id: '11',
    name: 'Shakespeare First Folio',
    description: 'Rare reproduction of Shakespeare\'s First Folio from 1623, museum quality with leather binding',
    price: 150,
    category: 'books',
    image: 'https://images.pexels.com/photos/1029141/pexels-photo-1029141.jpeg?auto=compress&cs=tinysrgb&w=500',
    rating: 4.9,
    available: true,
    specifications: {
      'Author': 'William Shakespeare',
      'Year': '1623 Reproduction',
      'Condition': 'Museum Quality',
      'Pages': '900+'
    },
    rentingPeriod: ['3 days', '1 week', '2 weeks'],
  },
  {
    id: '12',
    name: 'LED Dance Floor',
    description: 'Professional LED dance floor system perfect for weddings and corporate events',
    price: 350,
    category: 'party-supplies',
    image: 'https://images.pexels.com/photos/1190298/pexels-photo-1190298.jpeg?auto=compress&cs=tinysrgb&w=500',
    rating: 4.8,
    available: true,
    specifications: {
      'Size': '20x20 feet',
      'Type': 'RGB LED',
      'Control': 'Wireless DMX',
      'Power': '110V/220V'
    },
    rentingPeriod: ['1 day', '3 days', '1 week'],
  },
  {
    id: '13',
    name: 'Tiffany Diamond Earrings',
    description: 'Elegant Tiffany & Co. diamond stud earrings with platinum setting',
    price: 380,
    category: 'jewelry',
    image: 'https://images.pexels.com/photos/277390/pexels-photo-277390.jpeg?auto=compress&cs=tinysrgb&w=500',
    rating: 4.9,
    available: true,
    specifications: {
      'Brand': 'Tiffany & Co.',
      'Material': 'Platinum',
      'Stone': 'Diamond',
      'Carat': '2.0 total'
    },
    rentingPeriod: ['1 day', '3 days', '1 week', '2 weeks'],
  },
  {
    id: '14',
    name: 'Festive Lehenga Choli',
    description: 'Beautiful festive lehenga choli in emerald green with golden thread work',
    price: 220,
    category: 'clothing',
    image: 'https://images.pexels.com/photos/1536619/pexels-photo-1536619.jpeg?auto=compress&cs=tinysrgb&w=500',
    rating: 4.7,
    available: true,
    specifications: {
      'Brand': 'Anita Dongre',
      'Material': 'Georgette',
      'Style': 'Festive Lehenga',
      'Sizes': 'S-XXL Available'
    },
    rentingPeriod: ['1 day', '3 days', '1 week'],
  },
  {
    id: '15',
    name: 'Rare Art History Book',
    description: 'Limited edition art history book with original illustrations and gold leaf pages',
    price: 95,
    category: 'books',
    image: 'https://images.pexels.com/photos/90946/pexels-photo-90946.jpeg?auto=compress&cs=tinysrgb&w=500',
    rating: 4.8,
    available: true,
    specifications: {
      'Publisher': 'Taschen',
      'Edition': 'Limited Edition',
      'Pages': '500+',
      'Binding': 'Leather Bound'
    },
    rentingPeriod: ['3 days', '1 week', '2 weeks'],
  },
  {
    id: '16',
    name: 'Bulgari Gold Bracelet',
    description: 'Luxurious Bulgari gold bracelet with signature serpenti design',
    price: 320,
    category: 'jewelry',
    image: 'https://images.pexels.com/photos/1927259/pexels-photo-1927259.jpeg?auto=compress&cs=tinysrgb&w=500',
    rating: 4.8,
    available: true,
    specifications: {
      'Brand': 'Bulgari',
      'Material': '18K Yellow Gold',
      'Design': 'Serpenti',
      'Weight': '45g'
    },
    rentingPeriod: ['1 day', '3 days', '1 week'],
  },
  {
    id: '17',
    name: 'Vintage Literature Collection',
    description: 'Curated collection of vintage literature including Hemingway, Fitzgerald, and Steinbeck',
    price: 120,
    category: 'books',
    image: 'https://images.pexels.com/photos/159711/books-bookstore-book-reading-159711.jpeg?auto=compress&cs=tinysrgb&w=500',
    rating: 4.7,
    available: true,
    specifications: {
      'Collection': '10 Books',
      'Era': '1920s-1950s',
      'Condition': 'Very Good',
      'Authors': 'Classic American'
    },
    rentingPeriod: ['1 week', '2 weeks', '1 month'],
  },
  {
    id: '18',
    name: 'Reception Lehenga Set',
    description: 'Glamorous reception lehenga in blush pink with sequin work and net dupatta',
    price: 280,
    category: 'clothing',
    image: 'https://images.pexels.com/photos/1021693/pexels-photo-1021693.jpeg?auto=compress&cs=tinysrgb&w=500',
    rating: 4.9,
    available: true,
    specifications: {
      'Brand': 'Tarun Tahiliani',
      'Material': 'Net & Silk',
      'Style': 'Reception Wear',
      'Color': 'Blush Pink'
    },
    rentingPeriod: ['1 day', '3 days', '1 week'],
  },
];

// Pre-populated cart items for demonstration
export const sampleCartItems = [
  {
    id: 'cart-1',
    product: products.find(p => p.id === '7')!, // Cartier Diamond Necklace
    quantity: 1,
    rentPeriod: '3 days',
    startDate: '2025-01-20',
    endDate: '2025-01-23',
  },
  {
    id: 'cart-2',
    product: products.find(p => p.id === '13')!, // Tiffany Diamond Earrings
    quantity: 1,
    rentPeriod: '3 days',
    startDate: '2025-01-20',
    endDate: '2025-01-23',
  },
  {
    id: 'cart-3',
    product: products.find(p => p.id === '2')!, // Royal Silk Lehenga
    quantity: 1,
    rentPeriod: '1 week',
    startDate: '2025-01-25',
    endDate: '2025-02-01',
  },
  {
    id: 'cart-4',
    product: products.find(p => p.id === '14')!, // Festive Lehenga Choli
    quantity: 1,
    rentPeriod: '3 days',
    startDate: '2025-01-22',
    endDate: '2025-01-25',
  },
  {
    id: 'cart-5',
    product: products.find(p => p.id === '5')!, // First Edition Gatsby
    quantity: 1,
    rentPeriod: '1 week',
    startDate: '2025-01-20',
    endDate: '2025-01-27',
  },
  {
    id: 'cart-6',
    product: products.find(p => p.id === '17')!, // Vintage Literature Collection
    quantity: 1,
    rentPeriod: '2 weeks',
    startDate: '2025-01-20',
    endDate: '2025-02-03',
  },
];