import React, { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { CheckCircle, Download, Calendar, Truck, Package, Star, Clock } from 'lucide-react';

export default function PaymentSuccess() {
  const [orderNumber] = useState(`RNT${Date.now().toString().slice(-6)}`);
  const [currentDate] = useState(new Date().toLocaleDateString());
  const [estimatedDelivery] = useState(
    new Date(Date.now() + 24 * 60 * 60 * 1000).toLocaleDateString()
  );
  const [showConfetti, setShowConfetti] = useState(true);

  useEffect(() => {
    const timer = setTimeout(() => setShowConfetti(false), 3000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div className="min-h-screen bg-gradient-to-br from-green-50 to-emerald-100 relative overflow-hidden">
      {/* Animated Background Elements */}
      {showConfetti && (
        <div className="absolute inset-0 pointer-events-none">
          {[...Array(20)].map((_, i) => (
            <div
              key={i}
              className="absolute animate-bounce"
              style={{
                left: `${Math.random() * 100}%`,
                top: `${Math.random() * 100}%`,
                animationDelay: `${Math.random() * 2}s`,
                animationDuration: `${2 + Math.random() * 2}s`,
              }}
            >
              <Star className="h-4 w-4 text-yellow-400 fill-current" />
            </div>
          ))}
        </div>
      )}

      <div className="relative flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 min-h-screen">
        <div className="max-w-2xl w-full">
          <div className="bg-white rounded-3xl shadow-2xl overflow-hidden">
            {/* Success Header */}
            <div className="bg-gradient-to-r from-green-500 to-emerald-600 px-8 py-12 text-center text-white">
              <div className="mx-auto w-24 h-24 bg-white/20 backdrop-blur-sm rounded-full flex items-center justify-center mb-6 animate-pulse">
                <CheckCircle className="h-16 w-16 text-white" />
              </div>
              <h1 className="text-3xl font-bold mb-2">Order Confirmed!</h1>
              <p className="text-green-100 text-lg">
                Your luxury rental is on its way
              </p>
            </div>

            {/* Order Details */}
            <div className="px-8 py-8">
              <div className="bg-gradient-to-r from-gray-50 to-gray-100 rounded-2xl p-6 mb-8">
                <h2 className="text-xl font-bold text-gray-900 mb-4 flex items-center">
                  <Package className="h-6 w-6 text-purple-600 mr-2" />
                  Order Details
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Order Number:</span>
                      <span className="font-semibold text-gray-900">{orderNumber}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Order Date:</span>
                      <span className="font-semibold text-gray-900">{currentDate}</span>
                    </div>
                  </div>
                  <div className="space-y-3">
                    <div className="flex justify-between">
                      <span className="text-gray-600">Status:</span>
                      <span className="font-semibold text-green-600 flex items-center">
                        <div className="w-2 h-2 bg-green-500 rounded-full mr-2 animate-pulse"></div>
                        Confirmed
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-600">Estimated Delivery:</span>
                      <span className="font-semibold text-gray-900">{estimatedDelivery}</span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Timeline */}
              <div className="mb-8">
                <h3 className="font-bold text-gray-900 mb-6 flex items-center">
                  <Clock className="h-5 w-5 text-purple-600 mr-2" />
                  What happens next?
                </h3>
                <div className="space-y-4">
                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                      <CheckCircle className="h-5 w-5 text-white" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">Order Confirmed</p>
                      <p className="text-sm text-gray-600">Payment processed successfully</p>
                      <p className="text-xs text-green-600 font-medium">Completed</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-purple-500 rounded-full flex items-center justify-center animate-pulse">
                      <Package className="h-5 w-5 text-white" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">Preparing Your Items</p>
                      <p className="text-sm text-gray-600">Quality check and packaging in progress</p>
                      <p className="text-xs text-purple-600 font-medium">In Progress</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
                      <Truck className="h-5 w-5 text-white" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">Delivery Scheduled</p>
                      <p className="text-sm text-gray-600">We'll contact you to arrange delivery</p>
                      <p className="text-xs text-gray-500 font-medium">Pending</p>
                    </div>
                  </div>

                  <div className="flex items-start space-x-4">
                    <div className="flex-shrink-0 w-8 h-8 bg-gray-300 rounded-full flex items-center justify-center">
                      <Star className="h-5 w-5 text-white" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-gray-900">Enjoy Your Rental</p>
                      <p className="text-sm text-gray-600">Items delivered to your address</p>
                      <p className="text-xs text-gray-500 font-medium">Upcoming</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Action Buttons */}
              <div className="space-y-4">
                <button className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white py-4 px-6 rounded-xl font-semibold hover:from-purple-700 hover:to-indigo-700 transition-all duration-300 flex items-center justify-center space-x-2 shadow-lg">
                  <Download className="h-5 w-5" />
                  <span>Download Receipt & Invoice</span>
                </button>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <Link
                    to="/products"
                    className="bg-gray-100 text-gray-700 py-3 px-6 rounded-xl font-semibold hover:bg-gray-200 transition-colors text-center block"
                  >
                    Continue Shopping
                  </Link>
                  <button className="border-2 border-purple-600 text-purple-600 py-3 px-6 rounded-xl font-semibold hover:bg-purple-50 transition-colors">
                    Track Order
                  </button>
                </div>
              </div>

              {/* Contact Support */}
              <div className="mt-8 pt-6 border-t border-gray-200 text-center">
                <p className="text-sm text-gray-600 mb-2">
                  Questions about your order?
                </p>
                <div className="flex flex-col sm:flex-row items-center justify-center space-y-2 sm:space-y-0 sm:space-x-4">
                  <a 
                    href="mailto:support@rentify.com" 
                    className="text-purple-600 hover:text-purple-700 font-medium text-sm"
                  >
                    support@rentify.com
                  </a>
                  <span className="hidden sm:block text-gray-300">|</span>
                  <a 
                    href="tel:+15551234567" 
                    className="text-purple-600 hover:text-purple-700 font-medium text-sm"
                  >
                    +1 (555) 123-4567
                  </a>
                </div>
              </div>
            </div>
          </div>

          {/* Additional Info Card */}
          <div className="mt-8 bg-white/80 backdrop-blur-sm rounded-2xl p-6 border border-white/20">
            <div className="text-center">
              <h3 className="font-bold text-gray-900 mb-2">First Time Renting?</h3>
              <p className="text-gray-600 text-sm mb-4">
                Check out our rental guide for tips on caring for luxury items
              </p>
              <button className="text-purple-600 hover:text-purple-700 font-medium text-sm">
                View Rental Guide →
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}