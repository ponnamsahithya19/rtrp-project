import React from 'react';
import { Link } from 'react-router-dom';
import { Trash2, Plus, Minus, ShoppingBag, ArrowLeft, Calendar, Star, Shield, Truck } from 'lucide-react';
import { useApp } from '../context/AppContext';

export default function Cart() {
  const { state, dispatch } = useApp();

  const updateQuantity = (id: string, newQuantity: number) => {
    if (newQuantity === 0) {
      dispatch({ type: 'REMOVE_FROM_CART', payload: id });
    } else {
      dispatch({ type: 'UPDATE_CART_ITEM', payload: { id, updates: { quantity: newQuantity } } });
    }
  };

  const removeItem = (id: string) => {
    dispatch({ type: 'REMOVE_FROM_CART', payload: id });
  };

  const getTotalPrice = () => {
    return state.cart.reduce((total, item) => total + (item.product.price * item.quantity), 0);
  };

  const getItemsByCategory = () => {
    const jewelry = state.cart.filter(item => item.product.category === 'jewelry');
    const clothing = state.cart.filter(item => item.product.category === 'clothing');
    const books = state.cart.filter(item => item.product.category === 'books');
    return { jewelry, clothing, books };
  };

  const { jewelry, clothing, books } = getItemsByCategory();

  if (state.cart.length === 0) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-100 flex items-center justify-center">
        <div className="text-center bg-white rounded-2xl shadow-xl p-12 max-w-md mx-4">
          <ShoppingBag className="h-24 w-24 text-gray-300 mx-auto mb-6" />
          <h2 className="text-2xl font-bold text-gray-900 mb-4">Your cart is empty</h2>
          <p className="text-gray-600 mb-8">Start adding some luxury items to your cart!</p>
          <Link
            to="/products"
            className="bg-gradient-to-r from-purple-600 to-indigo-600 text-white px-8 py-3 rounded-lg font-semibold hover:from-purple-700 hover:to-indigo-700 transition-all duration-300 inline-block"
          >
            Browse Products
          </Link>
        </div>
      </div>
    );
  }

  const CategorySection = ({ title, items, icon }: { title: string; items: any[]; icon: React.ReactNode }) => {
    if (items.length === 0) return null;

    return (
      <div className="mb-8">
        <div className="flex items-center mb-4">
          {icon}
          <h3 className="text-xl font-bold text-gray-900 ml-2">{title}</h3>
          <span className="ml-2 bg-purple-100 text-purple-600 px-2 py-1 rounded-full text-sm font-medium">
            {items.length} {items.length === 1 ? 'item' : 'items'}
          </span>
        </div>
        <div className="space-y-4">
          {items.map((item) => (
            <div key={item.id} className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-shadow">
              <div className="flex items-center space-x-6">
                <div className="relative">
                  <img
                    src={item.product.image}
                    alt={item.product.name}
                    className="w-24 h-24 object-cover rounded-lg"
                  />
                  <div className="absolute -top-2 -right-2 bg-purple-600 text-white rounded-full w-6 h-6 flex items-center justify-center text-xs font-bold">
                    {item.quantity}
                  </div>
                </div>
                
                <div className="flex-1">
                  <h4 className="text-lg font-semibold text-gray-900 mb-1">{item.product.name}</h4>
                  <p className="text-gray-600 text-sm mb-2 line-clamp-2">{item.product.description}</p>
                  
                  <div className="flex items-center space-x-4 mb-3">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`h-4 w-4 ${
                            i < Math.floor(item.product.rating)
                              ? 'text-yellow-400 fill-current'
                              : 'text-gray-300'
                          }`}
                        />
                      ))}
                      <span className="text-sm text-gray-600 ml-1">({item.product.rating})</span>
                    </div>
                    <div className="flex items-center text-sm text-gray-500">
                      <Calendar className="h-4 w-4 mr-1" />
                      <span>{item.rentPeriod}</span>
                    </div>
                  </div>

                  <div className="flex items-center space-x-4 text-sm text-gray-500">
                    <span>From: {item.startDate}</span>
                    <span>To: {item.endDate}</span>
                  </div>
                </div>

                <div className="flex items-center space-x-4">
                  <div className="flex items-center space-x-2 bg-gray-100 rounded-lg p-1">
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity - 1)}
                      className="p-2 rounded-lg hover:bg-white transition-colors"
                    >
                      <Minus className="h-4 w-4 text-gray-600" />
                    </button>
                    <span className="w-8 text-center font-medium">{item.quantity}</span>
                    <button
                      onClick={() => updateQuantity(item.id, item.quantity + 1)}
                      className="p-2 rounded-lg hover:bg-white transition-colors"
                    >
                      <Plus className="h-4 w-4 text-gray-600" />
                    </button>
                  </div>

                  <div className="text-right">
                    <div className="text-xl font-bold text-purple-600">
                      ${(item.product.price * item.quantity).toFixed(2)}
                    </div>
                    <div className="text-sm text-gray-500">per day</div>
                  </div>

                  <button
                    onClick={() => removeItem(item.id)}
                    className="p-2 text-gray-400 hover:text-red-500 hover:bg-red-50 rounded-lg transition-colors"
                  >
                    <Trash2 className="h-5 w-5" />
                  </button>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    );
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-purple-50 to-indigo-100">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div className="flex items-center">
            <Link to="/products" className="flex items-center text-gray-600 hover:text-purple-600 transition-colors mr-6">
              <ArrowLeft className="h-5 w-5 mr-2" />
              Continue Shopping
            </Link>
            <h1 className="text-3xl font-bold text-gray-900">Your Luxury Cart</h1>
          </div>
          <div className="text-right">
            <p className="text-sm text-gray-600">Total Items</p>
            <p className="text-2xl font-bold text-purple-600">{state.cart.reduce((sum, item) => sum + item.quantity, 0)}</p>
          </div>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Cart Items */}
          <div className="lg:col-span-2">
            {/* Jewelry Section */}
            <CategorySection 
              title="Premium Jewelry" 
              items={jewelry} 
              icon={<div className="w-6 h-6 bg-yellow-400 rounded-full flex items-center justify-center">💎</div>}
            />

            {/* Clothing Section */}
            <CategorySection 
              title="Designer Lehengas" 
              items={clothing} 
              icon={<div className="w-6 h-6 bg-pink-400 rounded-full flex items-center justify-center">👗</div>}
            />

            {/* Books Section */}
            <CategorySection 
              title="Rare Books" 
              items={books} 
              icon={<div className="w-6 h-6 bg-blue-400 rounded-full flex items-center justify-center">📚</div>}
            />
          </div>

          {/* Order Summary */}
          <div className="lg:col-span-1">
            <div className="bg-white rounded-2xl shadow-xl p-6 sticky top-8">
              <h2 className="text-xl font-bold text-gray-900 mb-6">Order Summary</h2>
              
              {/* Summary by Category */}
              <div className="space-y-3 mb-6">
                {jewelry.length > 0 && (
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Jewelry ({jewelry.length} items)</span>
                    <span className="font-medium">${jewelry.reduce((sum, item) => sum + (item.product.price * item.quantity), 0).toFixed(2)}</span>
                  </div>
                )}
                {clothing.length > 0 && (
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Lehengas ({clothing.length} items)</span>
                    <span className="font-medium">${clothing.reduce((sum, item) => sum + (item.product.price * item.quantity), 0).toFixed(2)}</span>
                  </div>
                )}
                {books.length > 0 && (
                  <div className="flex justify-between text-sm">
                    <span className="text-gray-600">Books ({books.length} items)</span>
                    <span className="font-medium">${books.reduce((sum, item) => sum + (item.product.price * item.quantity), 0).toFixed(2)}</span>
                  </div>
                )}
              </div>

              <div className="border-t border-gray-200 pt-4 space-y-3 mb-6">
                <div className="flex justify-between">
                  <span className="text-gray-600">Subtotal</span>
                  <span className="font-medium">${getTotalPrice().toFixed(2)}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 flex items-center">
                    <Truck className="h-4 w-4 mr-1" />
                    Delivery
                  </span>
                  <span className="font-medium text-green-600">Free</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 flex items-center">
                    <Shield className="h-4 w-4 mr-1" />
                    Insurance (5%)
                  </span>
                  <span className="font-medium">${(getTotalPrice() * 0.05).toFixed(2)}</span>
                </div>
                <div className="border-t border-gray-200 pt-3">
                  <div className="flex justify-between text-lg font-bold">
                    <span>Total</span>
                    <span className="text-purple-600">${(getTotalPrice() * 1.05).toFixed(2)}</span>
                  </div>
                  <p className="text-sm text-gray-500 mt-1">per day</p>
                </div>
              </div>

              <Link
                to="/payment"
                className="w-full bg-gradient-to-r from-purple-600 to-indigo-600 text-white py-4 px-6 rounded-xl font-semibold hover:from-purple-700 hover:to-indigo-700 transition-all duration-300 text-center block shadow-lg"
              >
                Proceed to Payment
              </Link>

              {/* Security & Benefits */}
              <div className="mt-6 space-y-3">
                <div className="flex items-center text-sm text-gray-600">
                  <Shield className="h-4 w-4 text-green-500 mr-2" />
                  <span>Secure checkout with SSL encryption</span>
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Truck className="h-4 w-4 text-blue-500 mr-2" />
                  <span>Free delivery & pickup service</span>
                </div>
                <div className="flex items-center text-sm text-gray-600">
                  <Star className="h-4 w-4 text-yellow-500 mr-2" />
                  <span>Premium quality guarantee</span>
                </div>
              </div>

              {/* Promo Code */}
              <div className="mt-6 p-4 bg-gradient-to-r from-purple-50 to-indigo-50 rounded-lg">
                <p className="text-sm font-medium text-gray-900 mb-2">Have a promo code?</p>
                <div className="flex space-x-2">
                  <input
                    type="text"
                    placeholder="Enter code"
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-lg text-sm focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                  />
                  <button className="px-4 py-2 bg-purple-600 text-white rounded-lg text-sm font-medium hover:bg-purple-700 transition-colors">
                    Apply
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}