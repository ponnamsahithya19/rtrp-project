export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: string;
  image: string;
  rating: number;
  available: boolean;
  specifications: Record<string, string>;
  rentingPeriod: string[];
}

export interface User {
  id: string;
  name: string;
  email: string;
  phone: string;
  address: string;
}

export interface CartItem {
  id: string;
  product: Product;
  quantity: number;
  rentPeriod: string;
  startDate: string;
  endDate: string;
}

export interface Category {
  id: string;
  name: string;
  icon: string;
  description: string;
  productCount: number;
  image: string;
}